import React, { useEffect, useState } from "react";
import {
  Network,
  Database,
  Activity,
  Settings,
  MessageSquare,
  FolderOpen,
  Cloud,
  Clock,
  ChevronDown,
  ChevronUp,
  Edit,
  Save,
  X,
  Mail,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "./ui/collapsible";
import { useSelector } from "react-redux";
import { fetchEhTool, patchEhTool } from "../slices/ehToolsSlice";
import { toast } from "sonner";
import { useAppDispatch } from "../hooks";



export function EnrichmentToolConfig() {
  const dispatch = useAppDispatch();
  const { 
    dicomReceiver, 
    lisConnector, 
    enrichmentService,
    exportService,
    hl7Connector,
    emailService,
    loading 
  } = useSelector((s: any) => s.ehTools || {});

  const [editMode, setEditMode] = useState<{ [key: string]: boolean }>({
    dicom: false,
    lis: false,
    enrichment: false,
    export: false,
    hl7: false,
    email: false,
  });

  const [form, setForm] = useState({
    dicomReceiver: { aet: "", ipAddress: "", port: "", networkDrive: "" },
    lisConnector: { applicationName: "", ipAddress: "", receivingPort: "" },
    enrichmentService: { messageType: "OUL" },
    exportService: { synapseServerFolder: "gt450dx" },
    hl7Messaging: { applicationName: "eh-hl7-connector", ipAddress: "10.201.8.12", receivingPort: "2575", outputPort: "6661" },
    emailService: { emailFrom: "EnrichmentService@northshore.org", emailTo: "preeti.ankam@citiustech.com,rohini.kadam@citiustech.com", emailIbexTo: "preeti.ankam@citiustech.com,ravi.ranjan@citiustech.com" },
  });

  const [originalForm, setOriginalForm] = useState(form);

  // Fetch initial data
  useEffect(() => {
    dispatch(fetchEhTool({ toolKey: "eh-dicom-receiver" }));
    dispatch(fetchEhTool({ toolKey: "eh-lis-connector" }));
    dispatch(fetchEhTool({ toolKey: "eh-enrichment-service" }));
    dispatch(fetchEhTool({ toolKey: "eh-export-service" }));
    dispatch(fetchEhTool({ toolKey: "eh-hl7-connector" }));
    dispatch(fetchEhTool({ toolKey: "eh-email-service" }));
  }, [dispatch]);

  // Sync dicomReceiver
  useEffect(() => {
    if (dicomReceiver) {
      const newData = {
        aet: dicomReceiver["storescp.aetitle"] || dicomReceiver.aet || "",
        port: dicomReceiver["server.port"] || dicomReceiver.port || "",
        ipAddress: dicomReceiver["server.ipAddress"] || dicomReceiver.ipAddress || "",
        networkDrive: dicomReceiver["storescp.storage.path"] || dicomReceiver.networkDrive || "",
      };
      setForm((prev) => ({ ...prev, dicomReceiver: newData }));
      setOriginalForm((prev) => ({ ...prev, dicomReceiver: newData }));
    }
  }, [dicomReceiver]);

  // Sync lisConnector
  useEffect(() => {
    if (lisConnector) {
      const newData = {
        applicationName: lisConnector.name || lisConnector.appName || "",
        ipAddress: lisConnector["lis.ipAddress"] || lisConnector.ipAddress || "",
        receivingPort: lisConnector["lis.port"] || lisConnector.receivingPort || "",
      };
      setForm((prev) => ({ ...prev, lisConnector: newData }));
      setOriginalForm((prev) => ({ ...prev, lisConnector: newData }));
    }
  }, [lisConnector]);

  // Sync enrichmentService
  useEffect(() => {
    if (enrichmentService && enrichmentService.messageType) {
      const newData = {
        messageType: enrichmentService.messageType || "OUL",
      };
      setForm((prev) => ({ ...prev, enrichmentService: newData }));
      setOriginalForm((prev) => ({ ...prev, enrichmentService: newData }));
    }
  }, [enrichmentService]);

  // Sync exportService
  useEffect(() => {
    if (exportService && exportService.synapseServerFolder) {
      const newData = {
        synapseServerFolder: exportService.synapseServerFolder || "gt450dx",
      };
      setForm((prev) => ({ ...prev, exportService: newData }));
      setOriginalForm((prev) => ({ ...prev, exportService: newData }));
    }
  }, [exportService]);

  // Sync hl7Connector
  useEffect(() => {
    if (hl7Connector && Object.keys(hl7Connector).length > 0) {
      const newData = {
        applicationName: hl7Connector.name || "eh-hl7-connector",
        ipAddress: hl7Connector.ipAddress || "10.201.8.12",
        receivingPort: hl7Connector["receive-port"]?.toString() || hl7Connector.receivingPort?.toString() || "2575",
        outputPort: hl7Connector.outputPort?.toString() || "6661",
      };
      setForm((prev) => ({ ...prev, hl7Messaging: newData }));
      setOriginalForm((prev) => ({ ...prev, hl7Messaging: newData }));
    }
  }, [hl7Connector]);

  // Sync emailService
  useEffect(() => {
    if (emailService && Object.keys(emailService).length > 0) {
      const newData = {
        emailFrom: emailService.emailFrom || "EnrichmentService@northshore.org",
        emailTo: emailService.emailTo || "",
        emailIbexTo: emailService.emailIbexTo || "",
      };
      setForm((prev) => ({ ...prev, emailService: newData }));
      setOriginalForm((prev) => ({ ...prev, emailService: newData }));
    }
  }, [emailService]);

  const handleEdit = (key: keyof typeof editMode, enable: boolean) => {
    setEditMode((prev) => ({ ...prev, [key]: enable }));
    if (!enable) setForm(originalForm);
  };

  const handleChange = (
    section: keyof typeof form,
    field: string,
    value: string
  ) => {
    setForm((prev) => ({
      ...prev,
      [section]: { ...prev[section], [field]: value },
    }));
  };
  const handleSave = async (type: keyof typeof editMode) => {
    let toolKey = "";
    let body: any = {};
    let sectionName = "";
  
    // helper function for diff
    const getChangedFields = (current: any, original: any) => {
      const diff: any = {};
      Object.keys(current).forEach((k) => {
        if (current[k]?.toString().trim() !== original[k]?.toString().trim()) {
          diff[k] = current[k];
        }
      });
      return diff;
    };
  
    switch (type) {
      case "dicom":
        toolKey = "eh-dicom-receiver";
        sectionName = "DICOM Receiver";
  
        const dicomDiff = getChangedFields(form.dicomReceiver, originalForm.dicomReceiver);
        if (Object.keys(dicomDiff).length === 0) {
          toast.info("No changes detected");
          setEditMode((prev) => ({ ...prev, [type]: false }));
          return;
        }
  
        // remap keys to match API expectations
        body = {
          ...(dicomDiff.aet && { aet: dicomDiff.aet }),
          ...(dicomDiff.port && { port: dicomDiff.port }),
          ...(dicomDiff.ipAddress && { ipAddress: dicomDiff.ipAddress }),
          ...(dicomDiff.networkDrive && { "network-drive": dicomDiff.networkDrive }),
        };
        break;
  
      case "lis":
        toolKey = "eh-lis-connector";
        sectionName = "LIS Connector";
        const lisDiff = getChangedFields(form.lisConnector, originalForm.lisConnector);
        if (Object.keys(lisDiff).length === 0) {
          toast.info("No changes detected");
          setEditMode((prev) => ({ ...prev, [type]: false }));
          return;
        }
        body = {
          ...(lisDiff.applicationName && { appName: lisDiff.applicationName }),
          ...(lisDiff.ipAddress && { ipAddress: lisDiff.ipAddress }),
          ...(lisDiff.receivingPort && { port: lisDiff.receivingPort }),
        };
        break;
  
      case "enrichment":
        toolKey = "eh-enrichment-service";
        sectionName = "Enrichment Service";
        body = getChangedFields(form.enrichmentService, originalForm.enrichmentService);
        if (Object.keys(body).length === 0) {
          toast.info("No changes detected");
          setEditMode((prev) => ({ ...prev, [type]: false }));
          return;
        }
        break;
  
      case "export":
        toolKey = "eh-export-service";
        sectionName = "Export Service";
        body = getChangedFields(form.exportService, originalForm.exportService);
        if (Object.keys(body).length === 0) {
          toast.info("No changes detected");
          setEditMode((prev) => ({ ...prev, [type]: false }));
          return;
        }
        break;
  
      case "hl7":
        toolKey = "eh-hl7-connector";
        sectionName = "HL7 Messaging";
        const hl7Diff = getChangedFields(form.hl7Messaging, originalForm.hl7Messaging);
        if (Object.keys(hl7Diff).length === 0) {
          toast.info("No changes detected");
          setEditMode((prev) => ({ ...prev, [type]: false }));
          return;
        }
        body = {
          ...(hl7Diff.applicationName && { name: hl7Diff.applicationName }),
          ...(hl7Diff.ipAddress && { ipAddress: hl7Diff.ipAddress }),
          ...(hl7Diff.receivingPort && { "receive-port": parseInt(hl7Diff.receivingPort) }),
          ...(hl7Diff.outputPort && { outputPort: parseInt(hl7Diff.outputPort) }),
        };
        break;
  
      case "email":
        toolKey = "eh-email-service";
        sectionName = "Email Service";
        body = getChangedFields(form.emailService, originalForm.emailService);
        if (Object.keys(body).length === 0) {
          toast.info("No changes detected");
          setEditMode((prev) => ({ ...prev, [type]: false }));
          return;
        }
        break;
    }
  
    console.log("PATCH Request Body:", body);
    console.log("Tool Key:", toolKey);
  
    try {
      await dispatch(patchEhTool({ toolKey, body })).unwrap();
      toast.success(`${sectionName} updated successfully`);
  
      // ✅ Update only that section in originalForm
      setOriginalForm((prev) => ({
        ...prev,
        [type === "dicom"
          ? "dicomReceiver"
          : type === "lis"
          ? "lisConnector"
          : type === "enrichment"
          ? "enrichmentService"
          : type === "export"
          ? "exportService"
          : type === "hl7"
          ? "hl7Messaging"
          : "emailService"]: { ...form[
            type === "dicom"
              ? "dicomReceiver"
              : type === "lis"
              ? "lisConnector"
              : type === "enrichment"
              ? "enrichmentService"
              : type === "export"
              ? "exportService"
              : type === "hl7"
              ? "hl7Messaging"
              : "emailService"
          ] },
      }));
  
      setEditMode((prev) => ({ ...prev, [type]: false }));
    } catch (error) {
      console.error("Update error:", error);
      toast.error("Update failed. Try again.");
    }
  };
  

  const renderInput = (
    section: keyof typeof form,
    field: string,
    label: string,
    disabled: boolean
  ) => (
    <div className="space-y-2">
      <Label className="text-sm font-medium text-gray-700">{label}</Label>
      <Input
        value={(form as any)[section][field]}
        onChange={(e) => handleChange(section, field, e.target.value)}
        disabled={disabled}
        className={disabled ? "bg-gray-50 text-gray-600" : ""}
      />
    </div>
  );

  const renderDynamicCard = (
    title: string,
    icon: JSX.Element,
    keyName: keyof typeof editMode,
    section: keyof typeof form,
    fields: { field: string; label: string }[]
  ) => (
    <Card className="border border-gray-200 shadow-sm relative">
      <Collapsible defaultOpen>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer">
            <CardTitle className="flex items-center gap-2 text-lg">
              {icon} {title}
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="grid md:grid-cols-2 gap-6 relative pb-16">
            {fields.map((f) =>
              renderInput(section, f.field, f.label, !editMode[keyName])
            )}
            <div className="absolute bottom-4 right-4 flex gap-2">
              {editMode[keyName] ? (
                <>
                  <Button size="sm" onClick={() => handleSave(keyName)} disabled={loading}>
                    <Save className="h-4 w-4 mr-1" /> Save
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleEdit(keyName, false)}>
                    <X className="h-4 w-4 mr-1" /> Cancel
                  </Button>
                </>
              ) : (
                <Button size="sm" onClick={() => handleEdit(keyName, true)}>
                  <Edit className="h-4 w-4 mr-1" /> Edit
                </Button>
              )}
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );

  return (
    <div className="space-y-6 p-6 bg-white">
      {/* DICOM Receiver */}
      {renderDynamicCard(
        "DICOM Receiver",
        <Network className="h-5 w-5 text-blue-600" />,
        "dicom",
        "dicomReceiver",
        [
          { field: "aet", label: "AET" },
          { field: "ipAddress", label: "IP Address" },
          { field: "port", label: "Port" },
          { field: "networkDrive", label: "Network Drive" },
        ]
      )}

      {/* LIS Connector */}
      {renderDynamicCard(
        "LIS Connector",
        <Database className="h-5 w-5 text-blue-600" />,
        "lis",
        "lisConnector",
        [
          { field: "applicationName", label: "Application Name" },
          { field: "ipAddress", label: "IP Address" },
          { field: "receivingPort", label: "Receiving Port" },
        ]
      )}

      {/* Enrichment Service */}
      {renderDynamicCard(
        "Enrichment Service",
        <Activity className="h-5 w-5 text-blue-600" />,
        "enrichment",
        "enrichmentService",
        [
          { field: "messageType", label: "Message Type" },
        ]
      )}

      {/* Export Service */}
      {renderDynamicCard(
        "Export Service",
        <Cloud className="h-5 w-5 text-blue-600" />,
        "export",
        "exportService",
        [
          { field: "synapseServerFolder", label: "Synapse Server Folder" },
        ]
      )}

      {/* HL7 Messaging */}
      {renderDynamicCard(
        "HL7 Messaging",
        <MessageSquare className="h-5 w-5 text-blue-600" />,
        "hl7",
        "hl7Messaging",
        [
          { field: "applicationName", label: "Application Name" },
          { field: "ipAddress", label: "IP Address" },
          { field: "receivingPort", label: "Receiving Port" },
          { field: "outputPort", label: "Output Port" },
        ]
      )}

      {/* Email Service */}
      {renderDynamicCard(
        "Email Service",
        <Mail className="h-5 w-5 text-blue-600" />,
        "email",
        "emailService",
        [
          { field: "emailFrom", label: "Email From" },
          { field: "emailTo", label: "Email To" },
          { field: "emailIbexTo", label: "Email IBEX To" },
        ]
      )}
    </div>
  );
}