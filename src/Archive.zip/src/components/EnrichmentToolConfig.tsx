import React, { useEffect, useState } from "react";
import {
  Network,
  Database,
  Activity,
  Settings,
  MessageSquare,
  FolderOpen,
  Cloud,
  Clock,
  ChevronDown,
  ChevronUp,
  Edit,
  Save,
  X,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "./ui/collapsible";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "./ui/select";
import { useSelector } from "react-redux";
import { fetchEhTool, patchEhTool } from "../slices/ehToolsSlice";
import { toast } from "sonner";
import { useAppDispatch } from "../hooks";

interface EnrichmentConfig {
  dicomReceiver: {
    aet: string;
    ipAddress: string;
    port: string;
    networkDrive: string;
  };
  lisConnector: {
    applicationName: string;
    ipAddress: string;
    receivingPort: string;
    status: boolean;
  };
  enrichmentService: {
    enrichmentLogic: "customized" | "ihe-dpia";
    storageCommitment: "dicom-dir" | "storage-commitment" | "timeout";
    timeoutDuration?: string;
  };
  exportService: {
    sharedFolder: {
      enabled: boolean;
      location?: string;
    };
    visiopharm: boolean;
    ibex: boolean;
  };
  hl7Messaging: {
    applicationName: string;
    ipAddress: string;
    receivingPort: string;
    outputPort: string;
    threadPoolSize: string;
  };
}

const defaultConfig: EnrichmentConfig = {
  dicomReceiver: {
    aet: "ENRICHMENT_AET",
    ipAddress: "192.168.1.100",
    port: "4242",
    networkDrive: "\\\\server\\shared\\dicom",
  },
  lisConnector: {
    applicationName: "LIS Connector Service",
    ipAddress: "192.168.1.101",
    receivingPort: "8080",
    status: true,
  },
  enrichmentService: {
    enrichmentLogic: "customized",
    storageCommitment: "dicom-dir",
    timeoutDuration: "300",
  },
  exportService: {
    sharedFolder: {
      enabled: true,
      location: "\\\\server\\shared\\export",
    },
    visiopharm: false,
    ibex: true,
  },
  hl7Messaging: {
    applicationName: "HL7 Message Service",
    ipAddress: "192.168.1.102",
    receivingPort: "2575",
    outputPort: "2576",
    threadPoolSize: "5",
  },
};

export function EnrichmentToolConfig() {
  const dispatch = useAppDispatch();
  const { dicomReceiver, lisConnector, loading } = useSelector(
    (s: any) => s.ehTools || {}
  );

  const [editMode, setEditMode] = useState<{ [key: string]: boolean }>({
    dicom: false,
    lis: false,
  });

  const [form, setForm] = useState({
    dicomReceiver: { aet: "", ipAddress: "", port: "", networkDrive: "" },
    lisConnector: { applicationName: "", ipAddress: "", receivingPort: "" },
  });

  const [originalForm, setOriginalForm] = useState(form);
  const [config, setConfig] = useState<EnrichmentConfig>(defaultConfig);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(
    new Set([
      "dicom-receiver",
      "lis-connector",
      "enrichment-service",
      "export-service",
      "hl7-messaging",
    ])
  );

  const toggleSection = (sectionId: string) => {
    setExpandedSections((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(sectionId)) newSet.delete(sectionId);
      else newSet.add(sectionId);
      return newSet;
    });
  };

  const isExpanded = (sectionId: string) => expandedSections.has(sectionId);

  const updateConfig = (section: keyof EnrichmentConfig, field: string, value: any) => {
    setConfig((prev) => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value,
      },
    }));
  };

  const updateNestedConfig = (
    section: keyof EnrichmentConfig,
    nestedField: string,
    field: string,
    value: any
  ) => {
    setConfig((prev) => ({
      ...prev,
      [section]: {
        ...prev[section],
        [nestedField]: {
          ...(prev[section] as any)[nestedField],
          [field]: value,
        },
      },
    }));
  };

  // Fetch initial data
  useEffect(() => {
    dispatch(fetchEhTool({ toolKey: "eh-dicom-receiver" }));
    dispatch(fetchEhTool({ toolKey: "eh-lis-connector" }));
  }, [dispatch]);

  // Sync dicomReceiver
  useEffect(() => {
    if (dicomReceiver) {
      const newData = {
        aet: dicomReceiver["storescp.aetitle"] || dicomReceiver.aet || "",
        port: dicomReceiver["server.port"] || dicomReceiver.port || "",
        ipAddress: dicomReceiver["server.ipAddress"] || dicomReceiver.ipAddress || "",
        networkDrive:
          dicomReceiver["storescp.storage.path"] || dicomReceiver.networkDrive || "",
      };
      setForm((prev) => ({ ...prev, dicomReceiver: newData }));
      setOriginalForm((prev) => ({ ...prev, dicomReceiver: newData }));
    }
  }, [dicomReceiver]);

  // Sync lisConnector
  useEffect(() => {
    if (lisConnector) {
      const newData = {
        applicationName: lisConnector.name || lisConnector.appName || "",
        ipAddress: lisConnector["lis.ipAddress"] || lisConnector.ipAddress || "",
        receivingPort: lisConnector["lis.port"] || lisConnector.receivingPort || "",
      };
      setForm((prev) => ({ ...prev, lisConnector: newData }));
      setOriginalForm((prev) => ({ ...prev, lisConnector: newData }));
    }
  }, [lisConnector]);

  const handleEdit = (key: "dicom" | "lis", enable: boolean) => {
    setEditMode((prev) => ({ ...prev, [key]: enable }));
    if (!enable) setForm(originalForm);
  };

  const handleChange = (
    section: "dicomReceiver" | "lisConnector",
    field: string,
    value: string
  ) => {
    setForm((prev) => ({
      ...prev,
      [section]: { ...prev[section], [field]: value },
    }));
  };

  const handleSave = async (type: "dicom" | "lis") => {
    const current = form[type === "dicom" ? "dicomReceiver" : "lisConnector"];
    const original =
      originalForm[type === "dicom" ? "dicomReceiver" : "lisConnector"];

    for (const [k, v] of Object.entries(current)) {
      if (!v.trim()) {
        toast.error(`${k} cannot be empty`);
        return;
      }
    }

    const changed: any = {};
    for (const [k, v] of Object.entries(current)) {
      if (v !== (original as any)[k]) changed[k] = v;
    }

    if (!Object.keys(changed).length) {
      toast.info("No changes detected");
      setEditMode((prev) => ({ ...prev, [type]: false }));
      return;
    }

    let body;
    let toolKey;
    if (type === "dicom") {
      toolKey = "eh-dicom-receiver";
      body = {
        ...(changed.aet && { aet: changed.aet }),
        ...(changed.port && { port: changed.port }),
        ...(changed.ipAddress && { ipAddress: changed.ipAddress }),
        ...(changed.networkDrive && { "network-drive": changed.networkDrive }),
      };
    } else {
      toolKey = "eh-lis-connector";
      body = {
        ...(changed.applicationName && { appName: changed.applicationName }),
        ...(changed.ipAddress && { ipAddress: changed.ipAddress }),
        ...(changed.receivingPort && { port: changed.receivingPort }),
      };
    }

    try {
      await dispatch(patchEhTool({ toolKey, body })).unwrap();
      toast.success(
        `${type === "dicom" ? "DICOM Receiver" : "LIS Connector"} updated successfully`
      );
      setEditMode((prev) => ({ ...prev, [type]: false }));
      setOriginalForm(form);
    } catch {
      toast.error("Update failed. Try again.");
    }
  };

  const renderInput = (
    section: "dicomReceiver" | "lisConnector",
    field: string,
    label: string,
    disabled: boolean
  ) => (
    <div className="space-y-2">
      <Label className="text-sm font-medium text-gray-700">{label}</Label>
      <Input
        value={(form as any)[section][field]}
        onChange={(e) => handleChange(section, field, e.target.value)}
        disabled={disabled}
        className={disabled ? "bg-gray-50 text-gray-600" : ""}
      />
    </div>
  );

  const renderDynamicCard = (
    title: string,
    icon: JSX.Element,
    keyName: "dicom" | "lis",
    section: "dicomReceiver" | "lisConnector",
    fields: { field: string; label: string }[]
  ) => (
    <Card className="border border-gray-200 shadow-sm relative">
      <Collapsible defaultOpen>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer">
            <CardTitle className="flex items-center gap-2 text-lg">
              {icon} {title}
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="grid md:grid-cols-2 gap-6 relative">
            {fields.map((f) =>
              renderInput(section, f.field, f.label, !editMode[keyName])
            )}
            <div className="absolute bottom-4 right-4 flex gap-2">
              {editMode[keyName] ? (
                <>
                  <Button size="sm" onClick={() => handleSave(keyName)} disabled={loading}>
                    <Save className="h-4 w-4 mr-1" /> Save
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleEdit(keyName, false)}>
                    <X className="h-4 w-4 mr-1" /> Cancel
                  </Button>
                </>
              ) : (
                <Button size="sm" onClick={() => handleEdit(keyName, true)}>
                  <Edit className="h-4 w-4 mr-1" /> Edit
                </Button>
              )}
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );

  return (
    <div className="space-y-6 p-6 bg-white">
      {/* DICOM and LIS Cards */}
      {renderDynamicCard(
        "DICOM Receiver",
        <Network className="h-5 w-5 text-blue-600" />,
        "dicom",
        "dicomReceiver",
        [
          { field: "aet", label: "AET" },
          { field: "ipAddress", label: "IP Address" },
          { field: "port", label: "Port" },
          { field: "networkDrive", label: "Network Drive" },
        ]
      )}

      {renderDynamicCard(
        "LIS Connector",
        <Database className="h-5 w-5 text-blue-600" />,
        "lis",
        "lisConnector",
        [
          { field: "applicationName", label: "Application Name" },
          { field: "ipAddress", label: "IP Address" },
          { field: "receivingPort", label: "Receiving Port" },
        ]
      )}

      {/* Enrichment Service */}
      <Card>
        <Collapsible defaultOpen>
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Activity className="h-5 w-5 text-blue-600" /> Enrichment Service
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Enrichment Logic</Label>
                <Select
                  value={config.enrichmentService.enrichmentLogic}
                  onValueChange={(val) =>
                    updateConfig("enrichmentService", "enrichmentLogic", val)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select logic" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="customized">Customized</SelectItem>
                    <SelectItem value="ihe-dpia">IHE-DPIA</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Storage Commitment</Label>
                <Select
                  value={config.enrichmentService.storageCommitment}
                  onValueChange={(val) =>
                    updateConfig("enrichmentService", "storageCommitment", val)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dicom-dir">DICOMDIR</SelectItem>
                    <SelectItem value="storage-commitment">Storage Commitment</SelectItem>
                    <SelectItem value="timeout">Timeout</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Timeout Duration (sec)</Label>
                <Input
                  value={config.enrichmentService.timeoutDuration}
                  onChange={(e) =>
                    updateConfig("enrichmentService", "timeoutDuration", e.target.value)
                  }
                />
              </div>
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>

      {/* Export Service */}
      <Card>
        <Collapsible defaultOpen>
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Cloud className="h-5 w-5 text-blue-600" /> Export Service
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="grid md:grid-cols-2 gap-6">
              <div className="flex items-center gap-2">
                <Switch
                  checked={config.exportService.sharedFolder.enabled}
                  onCheckedChange={(checked: boolean) =>
                    updateNestedConfig("exportService", "sharedFolder", "enabled", checked)
                  }
                />
                <Label>Shared Folder Enabled</Label>
              </div>
              {config.exportService.sharedFolder.enabled && (
                <Input
                  value={config.exportService.sharedFolder.location}
                  onChange={(e) =>
                    updateNestedConfig(
                      "exportService",
                      "sharedFolder",
                      "location",
                      e.target.value
                    )
                  }
                  placeholder="Folder Path"
                />
              )}
              <div className="flex items-center gap-2">
                <Switch
                  checked={config.exportService.visiopharm}
                  onCheckedChange={(checked: boolean) =>
                    updateConfig("exportService", "visiopharm", checked)
                  }
                />
                <Label>Visiopharm</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={config.exportService.ibex}
                  onCheckedChange={(checked: boolean) =>
                    updateConfig("exportService", "ibex", checked)
                  }
                />
                <Label>IBEX</Label>
              </div>
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>

      {/* HL7 Messaging */}
      <Card>
        <Collapsible defaultOpen>
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer">
              <CardTitle className="flex items-center gap-2 text-lg">
                <MessageSquare className="h-5 w-5 text-blue-600" /> HL7 Messaging
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="grid md:grid-cols-2 gap-6">
              <Input
                value={config.hl7Messaging.applicationName}
                onChange={(e) =>
                  updateConfig("hl7Messaging", "applicationName", e.target.value)
                }
                placeholder="Application Name"
              />
              <Input
                value={config.hl7Messaging.ipAddress}
                onChange={(e) =>
                  updateConfig("hl7Messaging", "ipAddress", e.target.value)
                }
                placeholder="IP Address"
              />
              <Input
                value={config.hl7Messaging.receivingPort}
                onChange={(e) =>
                  updateConfig("hl7Messaging", "receivingPort", e.target.value)
                }
                placeholder="Receiving Port"
              />
              <Input
                value={config.hl7Messaging.outputPort}
                onChange={(e) =>
                  updateConfig("hl7Messaging", "outputPort", e.target.value)
                }
                placeholder="Output Port"
              />
              <Input
                value={config.hl7Messaging.threadPoolSize}
                onChange={(e) =>
                  updateConfig("hl7Messaging", "threadPoolSize", e.target.value)
                }
                placeholder="Thread Pool Size"
              />
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>
    </div>
  );
}
